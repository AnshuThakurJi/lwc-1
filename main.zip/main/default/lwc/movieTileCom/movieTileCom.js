import { LightningElement, api, track } from 'lwc';

export default class MovieTileCom extends LightningElement {

    // @api variable to received data from parent component so we call it parent to child communication.
    @api movie;
    @api selectedMovieId;

    @track clickedMovieId = null;

    clickHandler(event) {
        console.log('this.selectedMovieId => ', this.selectedMovieId);
        console.log('this.movie.imdbID => ', this.movie.imdbID);
        this.clickedMovieId = this.movie.imdbID;
        this.someMethod();
    }
    
    // child to parent communication (disptach custom event);
    //custom event sent from the component to the parent component
    someMethod() {
        const evt = new CustomEvent("selectedmovie", {
            detail: this.movie.imdbID
        });
        // You might need to dispatch it here
        this.dispatchEvent(evt);
    }

    get tileSelected() {
        return (this.selectedMovieId == this.movie.imdbID
        ? 'tile selected-tile' 
        : 'tile');  
    }
}