import { LightningElement, wire } from 'lwc';
import {APPLICATION_SCOPE, createMessageContext, MessageContext, publish, releaseMessageContext, subscribe, unsubscribe} from 'lightning/messageService';
import MOVIE_CHANNEL from '@salesforce/messageChannel/MovieChannel__c';
export default class MovieDetailCom extends LightningElement {
    subscription = null;
    loadComponent = false;
    movieId = null;

    @wire(MessageContext)
         messageContext;

    subscribeToMessageChannel() {
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext,
                MOVIE_CHANNEL,
                (message) => this.handleMessage(message),
                { scope: APPLICATION_SCOPE }
            );
        }
    }
     // Handler for message received by component
     handleMessage(message) {
        this.movieId = message.movieId;
         console.log("movieId =>", movieId);
         this.fetchMovieDetail(movieId);
     }
    unsubscribeToMessageChannel() {
        unsubscribe(this.subscription);
        this.subscription = null;
    }
    //connectCallBack for subsription channel.
    connectedCallback() {
        this.subscribeToMessageChannel();
    }
     //disconnectedCallBack for unsubscribe channel.
     disconnectedCallback() {
        this.unsubscribeToMessageChannel();
    }
   async fetchMovieDetail(movieId){
    let url = `https://www.omdbapi.com/?i=${movieId}&plot=full&apikey=5602d78d`;
     const res = await fetch(url);
     const data = await res.json();
      console.log("Movie detail output", data);
      this.loadComponent = true;
    }
}