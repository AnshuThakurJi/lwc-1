import { LightningElement, track, wire } from 'lwc';
// Import message service features required for publishing and the message channel
import { publish, MessageContext } from 'lightning/messageService';
import MOVIE_CHANNEL from '@salesforce/messageChannel/MovieChannel__c';
const DELAY = 300;
export default class MovieSearchCom extends LightningElement {
    selectedType = '';
    loading = false;
    selectedSearch = "";
    selectedPageNo = "1";
    delayTimeOut;
    searchResult = [];
    @wire(MessageContext)
    messageContext;
    //displaySearchResult = "";
    get typeoptions() {
        return [
            { label: 'None', value: 'none' },
            { label: 'Movie', value: 'movie' },
            { label: 'Series', value: 'series' },
            { label: 'Episodes', value: 'episode' },
        ];
    }
    handleChange(event) {
        let { name, value } = event.target;
        this.loading = true;
        if (name === 'type') {
            this.selectedType = value;
            console.log(this.selectedType);
        }
        else if (name === "Search") {
            this.selectedSearch = value;
            console.log(this.selectedSearch);
        } else if (name === 'pageno') {
            this.selectedPageNo = value;
            console.log(this.selectedPageNo);
        }
        //debouncing
        clearTimeout(this.delayTimeOut);
        this.delayTimeOut = setTimeout(() => {
            this.searchMovie();
        }, this.DELAY);
    }

    //this method will search for the entered movies

    async searchMovie() {
        const url = `https://www.omdbapi.com/?s=${this.selectedSearch}&type=${this.selectedType}&page=${this.selectedPageNo}&apikey=5602d78d`;
        const res = await fetch(url);
        const data = await res.json();
        console.log("Movie search output", data);
        this.loading = false;
        if (data.Response === "True") {
            this.searchResult = data.Search;
        }
    }

    @track selectedMovieId = null;

    selectedMovieHandler(event) {
        console.log('selectedMovieHandler => ', event);
        this.selectedMovieId = event.detail;
        console.log('this.selectedMovieId => ', this.selectedMovieId);

       const payload = { movieId:  this.selectedMovieId };
       console.log(`payload => `, payload);
      // publish(this.messageContext, MOVIE_CHANNEL, payload);

       // publish(this.messageContext, MOVIE_CHANNEL , payload);
    }
    get displaySearchResult() {
        return this.searchResult.length > 0 ? true : false;
    }
}
